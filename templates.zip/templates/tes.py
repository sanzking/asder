import os
import random
import string

def generate_random_string(length):
    """Generate a random string of letters and digits."""
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for i in range(length))

def create_random_folder():
    """Create a folder with a random name."""
    folder_name = generate_random_string(8)
    os.makedirs(folder_name)
    return folder_name

def create_random_file(folder):
    """Create a TXT file with a random name in the specified folder."""
    file_name = generate_random_string(10) + ".txt"
    file_path = os.path.join(folder, file_name)
    with open(file_path, 'w') as file:
        # You can customize the content of the TXT file here
        file.write("This is a random note.")
    return file_path

def main():
    # Create a random folder
    folder_name = create_random_folder()
    print(f"Folder created: {folder_name}")

    # Create a random TXT file in the folder
    file_path = create_random_file(folder_name)
    print(f"File created: {file_path}")

if __name__ == "__main__":
    main()
