from flask import Flask, render_template, request, redirect, url_for
import os
import hashlib
import string
import random

app = Flask(__name__)
notes = {}
PASSWORD = "Sanzking_123"

def hash_password(password):
    """Hash the password using SHA-256."""
    return hashlib.sha256(password.encode()).hexdigest()

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        entered_password = request.form.get('password')
        if entered_password == PASSWORD:
            return render_template('notes.html', notes=notes)
        else:
            return render_template('error.html', message='Incorrect password')

    return render_template('index.html')

@app.route('/create', methods=['GET', 'POST'])
def create_note():
    if request.method == 'POST':
        note_content = request.form.get('note_content')
        password = request.form.get('password')

        # Hash the password before storing
        hashed_password = hash_password(password)

        # Generate a random note ID
        note_id = generate_random_string(8)

        # Store the note with hashed password
        notes[note_id] = {'content': note_content, 'password': hashed_password}

        return redirect(url_for('index'))

    return render_template('create_note.html')

@app.route('/view/<note_id>', methods=['GET', 'POST'])
def view_note(note_id):
    note = notes.get(note_id)

    if note:
        if request.method == 'POST':
            entered_password = request.form.get('password')
            hashed_entered_password = hash_password(entered_password)

            if hashed_entered_password == note['password']:
                return render_template('view_note.html', note=note)
            else:
                return render_template('wrong_password.html')

        return render_template('enter_password.html', note_id=note_id)
    else:
        return render_template('note_not_found.html')

def generate_random_string(length):
    """Generate a random string of letters and digits."""
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for i in range(length))

if __name__ == '__main__':
    app.run(debug=True)
